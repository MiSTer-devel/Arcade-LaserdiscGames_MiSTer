# sc02-fpga

An FPGA implementation of the Votrax SC-02 / SSI-263 phoneme speech
synthesiser. Register-level behaviour follows the 1985 Votrax datasheet; the
vocal tract is a digital reimplementation of the chip's five cascaded
switched-capacitor sections.

Verified with Icarus Verilog: `make wav` produces `build/out.wav`, ~0.5 s of
speech built from a "hello world", a vowel sweep and a fricative set, driven
through the A/R handshake exactly as a host CPU would.

---

## Status

| Block | State |
|---|---|
| Host bus, 5 attribute registers, D7 read-back | done, datasheet-exact |
| Mode chart, CTL power-down, PD/RST | done |
| Frame / phoneme timing, A/R handshake | done |
| Target interpolation (formants, amplitude, pitch) | done |
| Glottal + noise excitation, inflection divider | done |
| 5-section resonator cascade, FF-scaled sample rate | done |
| Phoneme parameter ROM | **bootstrap data — see below** |
| Sections 4 and 5 individually programmable | not yet, fixed poles |

Measured against the bootstrap table, the synthesised vowels land within a few
percent of their intended formants:

```
        target F1/F2/F3      measured
EH      550 1750 2450        556 1731 2282
AE      700 1650 2400        677 1631 2296
AH      730 1200 2450        753 1185 2316
AW      600  950 2500        549  925 2600
ER      490 1350 1690        464 1206 1418
```

So the signal path is right. What is not yet right is *which numbers go in*.

---

## The ROM situation

The chip stores 64 phonemes' worth of vocal-tract parameters in an on-die mask
ROM. The datasheet publishes none of it.

For the SC-01/SC-01A this is a solved problem — the parts were decapped and the
ROMs read out in 2007, and MAME's `votrax.cpp` uses those parameters directly.
For the SC-02 the available artefact is the visual6502 SSI-263P die shot (203
images stitched to 17265 × 14313 by Greg James and Christian Sattler) and a
community read posted to comp.sys.apple2, identified there as **64 rows × 27
bits**, with the poster's own caveat that it might be flipped 180°.

**I could not retrieve those bits.** Google Groups rate-limited the fetch and
the narkive mirror blocks automated access. So `rom/sc02_phoneme_rom.bin`
currently holds a **bootstrap table generated from ordinary published formant
targets** for the sounds named in the datasheet phoneme chart. It is not the
die read, it is not claimed to be, and it exists only so the rest of the design
can be exercised and measured today.

Swapping in the real read is one command:

```sh
make rom BITS=rom/die_read.bits        # 64 lines of 27 '0'/'1' characters
make wav
```

### Which way up is the ROM?

Three independent unknowns, each with its own escape hatch:

**Row order** — is the top row phoneme 0x00 or 0x3F? Two ways to test:

```sh
make flip BITS=rom/die_read.bits   # renders as_read.wav and rotated.wav
```

or leave the ROM alone and toggle the `rom_row_flip` pin on `sc02_top`, which
addresses `~phoneme` instead of `phoneme`. Wire it to a DIP switch and A/B it
live on hardware without a rebuild.

**Bit order** — is bit 26 on the left or the right of the image?
`tools/rom_build.py --bit-reverse`. `--rotate180` does both at once, which is
the specific failure mode the original poster flagged.

**Field map** — which bits are F1, which are the amplitudes, and so on. This is
the one that cannot be resolved by listening to a whole phrase, because a wrong
field map does not sound "backwards", it sounds like static. `FIELDS` at the
top of `tools/rom_build.py` is the single place it is defined; the RTL slices
`sc02_rom.v` to match and nothing else in the design cares.

The current hypothesis, chosen to total exactly 27 bits and to mirror the
parameter set MAME recovered from the SC-01:

```
[26:23] F1   [22:18] F2   [17:15] F2Q  [14:11] F3
[10:7]  FA   [6:3]   VA   [2] CL  [1] VD  [0] PA
```

The SC-02 needs no duration field — duration comes from the DR1/DR0 register
bits — which frees the width the SC-01 spent on it. That is the reasoning; it
is not evidence.

### Bringing up an unknown read, in order

1. **Pause and closure bits first.** Play every code 0x00–0x3F in turn. Exactly
   one should be silent (PA at 0x00) and the hold/closure group (0x2B, 0x2D,
   0x2E) should be near-silent. If silence lands on 0x3F instead of 0x00, the
   row order is inverted — flip and repeat. This test needs no field map to be
   correct beyond the three single-bit flags, so do it before anything else.
2. **Voiced flag.** With row order settled, voiced codes should buzz and
   unvoiced ones should hiss. If it is the other way round, VD is inverted or
   sits elsewhere in the word.
3. **Amplitude fields.** Sweep the global amplitude register and check the
   per-phoneme relative levels track sensibly. A field map error usually shows
   up here as phonemes at wildly wrong relative loudness.
4. **Formants last.** Record a real SSI-263 saying the same phoneme sequence,
   take spectrograms of both, and compare formant tracks. This is where the
   remaining work is, and it is the part that takes weeks rather than an
   afternoon.

---

## Design notes

**Sample rate is the switched-capacitor clock.** The tract sections in the real
part are switched-capacitor, so they are already discrete-time, clocked at
`Fs = XCK / (2*(256-FF))`. The digital biquads run at that same rate, which
makes the mapping structural rather than an approximation of a continuous-time
network. It also means the Filter Frequency register works for free: because
formant frequencies and Fs scale together, the coefficients depend only on the
interpolated formant code, and writing FF moves the sample rate and the whole
spectrum with it — the datasheet's "vocal tract length" / voice-type control,
which does not touch pitch.

**Coefficients are Q21, not Q14.** Each section is
`y = (A*x + B*y1 - C*y2) >> 21` with `B = 2r·cosθ`, `C = r²`, `A = 1 - B + C`.
A is a difference of two nearly equal numbers — about 4e-4 for a narrow formant
— so in Q14 it rounds to the integer 7 and the voiced path quantises itself
into silence. This design hit that exact bug during bring-up. If you retune
bandwidths, keep an eye on it.

**Excitation is an impulse train plus a DC blocker,** not a doublet. A doublet
avoids the DC offset without extra logic, but its spectrum nulls at 0 Hz and
rolls off towards the formants, which starves F1. The impulse is spectrally
flat; a first-order high pass at the output removes the offset.

**One multiplier, time-shared.** Five sections × 7 states = 35 clocks per audio
sample. At 20 kHz on a 50 MHz fabric there are ~2500 available, so the whole
tract is a single 24×24 signed multiply and a small coefficient RAM.

### Known deviations from the real part

- Sections 4 and 5 are fixed poles (a ~3.6 kHz upper formant and a ~4.8 kHz
  spectral tilt) rather than individually programmable. The datasheet says all
  five are programmable; the field map above has no bits left for them, which
  is itself a hint the real field map differs. The visible symptom is that /s/
  and /sh/ lose their top end — measured F3 for S comes out at 3.5 kHz where
  the target is 6.5 kHz.
- Amplitude slews at the articulation tick. The datasheet says amplitude
  transitions at a rate dependent on the *duration* setting.
- Transitioned inflection is interpreted as: I10:I6 is the pitch target, I5:I3
  the rate of change, I11 and I2:I0 always immediate. The datasheet is terse
  and this is the reading that makes its two sentences consistent, but it
  quantises the pitch target to 32 steps. Worth checking against silicon.
- Write timing is edge-detected in the FPGA clock domain rather than modelled
  as the datasheet's Ts/Th/Tws analogue timings. Fine for any real host.

---

## Layout

```
rtl/sc02_top.v       pin wrapper: tri-state D7, open-collector A/R
rtl/sc02_core.v      clock enables, integration, DC blocker, sigma-delta
rtl/sc02_regs.v      host bus + the five attribute registers
rtl/sc02_seq.v       frame/phoneme timing, A/R, target interpolators
rtl/sc02_rom.v       64 x 27 phoneme ROM, runtime row_flip
rtl/sc02_excite.v    glottal pulse + LFSR noise
rtl/sc02_filter.v    5-section cascade on a shared multiplier
tools/sc02_maps.py   formant code -> frequency ladders (shared by both tools)
tools/coef_build.py  cos/radius/formant-map LUTs
tools/rom_build.py   bootstrap table + ROM packer with orientation flags
tools/pcm_to_wav.py  sim output -> listenable wav
tb/tb_sc02.v         host-side driver, full phrase
tb/tb_probe.v        single-vowel internal state trace
```

## Build

```sh
make wav       # luts + rom + compile + simulate + build/out.wav
make probe     # trace pitch, amplitudes, formants through one vowel
make sim       # simulate only
```

Retuning the voice does not need RTL changes: edit `theta()` or the bandwidth
range in `tools/coef_build.py`, or the ladders in `tools/sc02_maps.py`, and
rebuild.
