Pioneer LD-V1000 EPROM SWAP
For use in Badlands by Konami
02.22.01

Konami modified the LD-V1000's ROM to include an extra command which enhances game play.  It allows the same scenes to play differently and adds to the random element in the game.
A standard Pioneer LD-V1000 will not work in a Badlands.  The EPROM inside the laserdisc player must be changed first.